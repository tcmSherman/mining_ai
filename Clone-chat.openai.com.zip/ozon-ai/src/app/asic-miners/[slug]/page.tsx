import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  ArrowLeft,
  Truck,
  Shield,
  Clock,
  ShoppingCart,
  Heart,
  Share2,
  MessageSquare,
  CheckCircle,
  Info
} from "lucide-react";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

// Mockup data for a specific miner
const getMinerData = (slug: string) => {
  // Default miner data (S19 Pro+ Hyd)
  const defaultMiner = {
    slug: "antminer-s19-pro-hyd",
    name: "Antminer S19 Pro+ Hyd (198 Th/s)",
    description: "Bitmain Antminer S19 Pro+ Hydro - флагманский майнер с жидкостным охлаждением, обеспечивающий максимальную производительность и энергоэффективность.",
    image: "/antminer-s19-pro.png",
    price: "1 590 000 ₽",
    oldPrice: "1 750 000 ₽",
    status: "В наличии",
    algorithm: "SHA-256",
    hashrate: "198 Th/s",
    power: "5445W",
    efficiency: "27.5 J/Th",
    dimensions: "400 x 195 x 290 мм",
    weight: "15 кг",
    warranty: "12 месяцев",
    delivery: "3-5 дней",
    features: [
      "Жидкостное охлаждение",
      "Высокая производительность",
      "Энергоэффективность",
      "Официальная гарантия",
      "Техническая поддержка"
    ],
    specifications: [
      { name: "Производитель", value: "Bitmain" },
      { name: "Модель", value: "Antminer S19 Pro+ Hyd" },
      { name: "Алгоритм", value: "SHA-256" },
      { name: "Хешрейт", value: "198 Th/s ±5%" },
      { name: "Энергопотребление", value: "5445W ±5%" },
      { name: "Энергоэффективность", value: "27.5 J/Th" },
      { name: "Рабочая температура", value: "5-35°C" },
      { name: "Сетевой интерфейс", value: "Ethernet" },
      { name: "Система охлаждения", value: "Жидкостная" },
      { name: "Размеры", value: "400 x 195 x 290 мм" },
      { name: "Вес", value: "15 кг" },
      { name: "Уровень шума", value: "75 дБ" }
    ],
    relatedProducts: [
      {
        slug: "antminer-s19j-pro",
        name: "Antminer S19j Pro (104 Th/s)",
        image: "/antminer-s19j-pro.png",
        price: "760 000 ₽",
        status: "В наличии"
      },
      {
        slug: "whatsminer-m50s",
        name: "WhatsMiner M50S (126 Th/s)",
        image: "/whatsminer-m50s.png",
        price: "895 000 ₽",
        status: "Предзаказ"
      },
      {
        slug: "avalon-a1366",
        name: "Avalon A1366 (90 Th/s)",
        image: "/avalon-a1366.png",
        price: "580 000 ₽",
        status: "В наличии"
      }
    ]
  };

  // Data for different miners
  const minersData = {
    "antminer-s21-pro": {
      slug: "antminer-s21-pro",
      name: "Bitmain Antminer S21 Pro (200 Th/s)",
      description: "Bitmain Antminer S21 Pro - новейшая модель ASIC-майнера от компании Bitmain с рекордной производительностью и энергоэффективностью для майнинга Bitcoin.",
      image: "/antminer-s19-pro.png", // Reusing image for now
      price: "1 950 000 ₽",
      oldPrice: "",
      status: "Предзаказ",
      algorithm: "SHA-256",
      hashrate: "200 Th/s",
      power: "3400W",
      efficiency: "17.0 J/Th",
      dimensions: "430 x 195 x 290 мм",
      weight: "16 кг",
      warranty: "12 месяцев",
      delivery: "По предзаказу",
      features: [
        "Рекордная энергоэффективность",
        "Высокий хешрейт",
        "Улучшенная система охлаждения",
        "Официальная гарантия",
        "Техническая поддержка"
      ],
      specifications: [
        { name: "Производитель", value: "Bitmain" },
        { name: "Модель", value: "Antminer S21 Pro" },
        { name: "Алгоритм", value: "SHA-256" },
        { name: "Хешрейт", value: "200 Th/s ±5%" },
        { name: "Энергопотребление", value: "3400W ±5%" },
        { name: "Энергоэффективность", value: "17.0 J/Th" },
        { name: "Рабочая температура", value: "5-40°C" },
        { name: "Сетевой интерфейс", value: "Ethernet" },
        { name: "Система охлаждения", value: "Воздушная" },
        { name: "Размеры", value: "430 x 195 x 290 мм" },
        { name: "Вес", value: "16 кг" },
        { name: "Уровень шума", value: "70 дБ" }
      ],
      relatedProducts: [
        {
          slug: "antminer-s21",
          name: "Antminer S21 (185 Th/s)",
          image: "/antminer-s19j-pro.png",
          price: "1 750 000 ₽",
          status: "Предзаказ"
        },
        {
          slug: "antminer-t21",
          name: "Antminer T21 (170 Th/s)",
          image: "/antminer-s19-pro.png",
          price: "1 420 000 ₽",
          status: "В наличии"
        },
        {
          slug: "antminer-s19-xp",
          name: "Antminer S19 XP (140 Th/s)",
          image: "/antminer-s19-pro.png",
          price: "1 120 000 ₽",
          status: "В наличии"
        }
      ]
    },
    "antminer-s21": {
      slug: "antminer-s21",
      name: "Bitmain Antminer S21 (185 Th/s)",
      description: "Bitmain Antminer S21 - высокопроизводительный ASIC-майнер нового поколения с улучшенной энергоэффективностью и производительностью для майнинга Bitcoin.",
      image: "/antminer-s19j-pro.png", // Reusing image for now
      price: "1 750 000 ₽",
      oldPrice: "",
      status: "Предзаказ",
      algorithm: "SHA-256",
      hashrate: "185 Th/s",
      power: "3450W",
      efficiency: "18.7 J/Th",
      dimensions: "430 x 195 x 290 мм",
      weight: "15 кг",
      warranty: "12 месяцев",
      delivery: "По предзаказу",
      features: [
        "Высокая энергоэффективность",
        "Повышенный хешрейт",
        "Улучшенная система охлаждения",
        "Официальная гарантия",
        "Техническая поддержка"
      ],
      specifications: [
        { name: "Производитель", value: "Bitmain" },
        { name: "Модель", value: "Antminer S21" },
        { name: "Алгоритм", value: "SHA-256" },
        { name: "Хешрейт", value: "185 Th/s ±5%" },
        { name: "Энергопотребление", value: "3450W ±5%" },
        { name: "Энергоэффективность", value: "18.7 J/Th" },
        { name: "Рабочая температура", value: "5-40°C" },
        { name: "Сетевой интерфейс", value: "Ethernet" },
        { name: "Система охлаждения", value: "Воздушная" },
        { name: "Размеры", value: "430 x 195 x 290 мм" },
        { name: "Вес", value: "15 кг" },
        { name: "Уровень шума", value: "70 дБ" }
      ],
      relatedProducts: [
        {
          slug: "antminer-s21-pro",
          name: "Antminer S21 Pro (200 Th/s)",
          image: "/antminer-s19-pro.png",
          price: "1 950 000 ₽",
          status: "Предзаказ"
        },
        {
          slug: "antminer-t21",
          name: "Antminer T21 (170 Th/s)",
          image: "/antminer-s19-pro.png",
          price: "1 420 000 ₽",
          status: "В наличии"
        },
        {
          slug: "antminer-s19-xp",
          name: "Antminer S19 XP (140 Th/s)",
          image: "/antminer-s19-pro.png",
          price: "1 120 000 ₽",
          status: "В наличии"
        }
      ]
    },
    "antminer-t21": {
      slug: "antminer-t21",
      name: "Bitmain Antminer T21 (170 Th/s)",
      description: "Bitmain Antminer T21 - доступный ASIC-майнер новой серии с хорошим балансом производительности и энергопотребления для майнинга Bitcoin.",
      image: "/antminer-s19-pro.png", // Reusing image for now
      price: "1 420 000 ₽",
      oldPrice: "1 550 000 ₽",
      discount: "9%",
      status: "В наличии",
      algorithm: "SHA-256",
      hashrate: "170 Th/s",
      power: "3400W",
      efficiency: "20.0 J/Th",
      dimensions: "430 x 195 x 290 мм",
      weight: "15 кг",
      warranty: "12 месяцев",
      delivery: "3-5 дней",
      features: [
        "Доступная цена",
        "Хороший хешрейт",
        "Сбалансированное энергопотребление",
        "Официальная гарантия",
        "Техническая поддержка"
      ],
      specifications: [
        { name: "Производитель", value: "Bitmain" },
        { name: "Модель", value: "Antminer T21" },
        { name: "Алгоритм", value: "SHA-256" },
        { name: "Хешрейт", value: "170 Th/s ±5%" },
        { name: "Энергопотребление", value: "3400W ±5%" },
        { name: "Энергоэффективность", value: "20.0 J/Th" },
        { name: "Рабочая температура", value: "5-40°C" },
        { name: "Сетевой интерфейс", value: "Ethernet" },
        { name: "Система охлаждения", value: "Воздушная" },
        { name: "Размеры", value: "430 x 195 x 290 мм" },
        { name: "Вес", value: "15 кг" },
        { name: "Уровень шума", value: "72 дБ" }
      ],
      relatedProducts: [
        {
          slug: "antminer-s21",
          name: "Antminer S21 (185 Th/s)",
          image: "/antminer-s19j-pro.png",
          price: "1 750 000 ₽",
          status: "Предзаказ"
        },
        {
          slug: "antminer-s21-pro",
          name: "Antminer S21 Pro (200 Th/s)",
          image: "/antminer-s19-pro.png",
          price: "1 950 000 ₽",
          status: "Предзаказ"
        },
        {
          slug: "antminer-s19-xp",
          name: "Antminer S19 XP (140 Th/s)",
          image: "/antminer-s19-pro.png",
          price: "1 120 000 ₽",
          status: "В наличии"
        }
      ]
    }
    // Add more miners here for other slugs
  };

  // Return the specific miner data or default if not found
  return minersData[slug] || defaultMiner;
};

// В реальном приложении в этом месте был бы запрос к базе данных или API
const minersSlugList = [
  "antminer-s19-pro-hyd",
  "antminer-s19j-pro",
  "whatsminer-m50s",
  "avalon-a1366",
  "antminer-s19-xp",
  "whatsminer-m30s++",
  "antminer-l7",
  "antminer-e9",
  "antminer-s21-pro",
  "antminer-s21",
  "antminer-t21"
];

export function generateStaticParams() {
  return minersSlugList.map(slug => ({ slug }));
}

type PageProps = {
  params: { slug: string };
};

export default function MinerPage({ params }: { params: { slug: string } }) {
  const minerData = getMinerData(params.slug);

  // Metadata (use this approach instead of generateMetadata for simplicity)
  const title = `${minerData.name} - Купить ASIC-майнер с доставкой | MiningTech`;
  const description = minerData.description;

  return (
    <div className="space-y-8">
      {/* Adding metadata with next/head is removed for now */}

      {/* Breadcrumbs */}
      <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
        <Link href="/" className="hover:text-green-500 hover:underline">Главная</Link>
        <span className="mx-2">/</span>
        <Link href="/asic-miners" className="hover:text-green-500 hover:underline">ASIC-майнеры</Link>
        <span className="mx-2">/</span>
        <span className="text-gray-700 dark:text-gray-300">{minerData.name}</span>
      </div>

      {/* Product Info */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <Link href="/asic-miners" className="inline-flex items-center text-gray-600 hover:text-green-500 dark:text-gray-400 dark:hover:text-green-400">
            <ArrowLeft className="h-4 w-4 mr-1" />
            <span>Назад к списку майнеров</span>
          </Link>

          <div className="relative aspect-square bg-gray-100 rounded-lg overflow-hidden dark:bg-gray-800">
            <Image
              src={minerData.image}
              alt={minerData.name}
              fill
              className="object-contain p-6"
            />
            <div className="absolute top-4 left-4">
              <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium dark:bg-green-900 dark:text-green-200">
                {minerData.status}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="aspect-square bg-gray-100 rounded-lg overflow-hidden cursor-pointer hover:ring-2 hover:ring-green-500 dark:bg-gray-800">
                <div className="w-full h-full flex items-center justify-center">
                  <Image
                    src={minerData.image}
                    alt={`${minerData.name} view ${i}`}
                    width={100}
                    height={100}
                    className="object-contain p-2"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold mb-3 dark:text-white">{minerData.name}</h1>
            <div className="flex items-center space-x-6 mb-4">
              <div className="flex items-center">
                <div className="h-3 w-3 rounded-full bg-green-500 mr-2"></div>
                <span className="text-green-600 dark:text-green-400">{minerData.status}</span>
              </div>
              <div className="text-gray-500 dark:text-gray-400">Артикул: ASIC-123456</div>
            </div>
            <p className="text-gray-600 dark:text-gray-300">{minerData.description}</p>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg dark:bg-gray-800">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-gray-500 text-sm dark:text-gray-400">Алгоритм</p>
                <p className="font-medium dark:text-white">{minerData.algorithm}</p>
              </div>
              <div>
                <p className="text-gray-500 text-sm dark:text-gray-400">Хешрейт</p>
                <p className="font-medium dark:text-white">{minerData.hashrate}</p>
              </div>
              <div>
                <p className="text-gray-500 text-sm dark:text-gray-400">Потребление</p>
                <p className="font-medium dark:text-white">{minerData.power}</p>
              </div>
              <div>
                <p className="text-gray-500 text-sm dark:text-gray-400">Эффективность</p>
                <p className="font-medium dark:text-white">{minerData.efficiency}</p>
              </div>
            </div>
          </div>

          <div className="flex items-end justify-between">
            <div>
              <p className="text-gray-500 line-through text-sm dark:text-gray-400">{minerData.oldPrice}</p>
              <p className="text-3xl font-bold dark:text-white">{minerData.price}</p>
              <p className="text-green-600 text-sm dark:text-green-400">Экономия 160 000 ₽</p>
            </div>
            <div className="flex space-x-3">
              <Button variant="outline" size="icon" className="rounded-full border-gray-200 dark:border-gray-700">
                <Heart className="h-5 w-5 text-gray-600 dark:text-gray-400" />
              </Button>
              <Button variant="outline" size="icon" className="rounded-full border-gray-200 dark:border-gray-700">
                <Share2 className="h-5 w-5 text-gray-600 dark:text-gray-400" />
              </Button>
              <Button className="bg-green-500 hover:bg-green-600 text-white px-6">
                <ShoppingCart className="h-5 w-5 mr-2" />
                В корзину
              </Button>
            </div>
          </div>

          <div className="space-y-3 pt-2">
            <div className="flex items-start">
              <Truck className="h-5 w-5 text-gray-600 mr-3 mt-0.5 flex-shrink-0 dark:text-gray-400" />
              <div>
                <h3 className="font-medium dark:text-white">Доставка</h3>
                <p className="text-gray-600 text-sm dark:text-gray-300">По Москве и Санкт-Петербургу: {minerData.delivery}. Доставка по России и СНГ курьерской службой.</p>
              </div>
            </div>
            <div className="flex items-start">
              <Shield className="h-5 w-5 text-gray-600 mr-3 mt-0.5 flex-shrink-0 dark:text-gray-400" />
              <div>
                <h3 className="font-medium dark:text-white">Гарантия</h3>
                <p className="text-gray-600 text-sm dark:text-gray-300">Официальная гарантия производителя {minerData.warranty}. Расширенная гарантия и сервисное обслуживание.</p>
              </div>
            </div>
            <div className="flex items-start">
              <Clock className="h-5 w-5 text-gray-600 mr-3 mt-0.5 flex-shrink-0 dark:text-gray-400" />
              <div>
                <h3 className="font-medium dark:text-white">Окупаемость</h3>
                <p className="text-gray-600 text-sm dark:text-gray-300">Примерная окупаемость от 8 месяцев при текущем курсе Bitcoin и стоимости электроэнергии 5 руб/кВтч.</p>
              </div>
            </div>
          </div>

          <div className="border-t pt-6 dark:border-gray-700">
            <h3 className="font-medium mb-3 dark:text-white">Особенности</h3>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {minerData.features.map((feature, index) => (
                <li key={index} className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="pt-4">
            <Button variant="outline" className="w-full border-gray-200 hover:border-green-500 dark:border-gray-700 dark:hover:border-green-500 dark:text-white" size="lg">
              <MessageSquare className="h-5 w-5 mr-2 text-green-500" />
              Получить консультацию по этому майнеру
            </Button>
          </div>
        </div>
      </div>

      {/* Product Details */}
      <Tabs defaultValue="description" className="mt-10">
        <TabsList className="w-full justify-start border-b rounded-none">
          <TabsTrigger value="description" className="rounded-t-lg rounded-b-none data-[state=active]:border-b-2 data-[state=active]:border-green-500">
            Описание
          </TabsTrigger>
          <TabsTrigger value="specifications" className="rounded-t-lg rounded-b-none data-[state=active]:border-b-2 data-[state=active]:border-green-500">
            Характеристики
          </TabsTrigger>
          <TabsTrigger value="reviews" className="rounded-t-lg rounded-b-none data-[state=active]:border-b-2 data-[state=active]:border-green-500">
            Отзывы
          </TabsTrigger>
        </TabsList>

        <TabsContent value="description" className="pt-6">
          <div className="space-y-4 dark:text-gray-300">
            <p>
              <strong>Antminer S19 Pro+ Hyd (198 Th/s)</strong> - это высокопроизводительный ASIC-майнер с жидкостным охлаждением от компании Bitmain. Модель представляет собой флагманское решение для майнинга криптовалют на алгоритме SHA-256 (Bitcoin, Bitcoin Cash).
            </p>
            <p>
              Данная модель отличается значительно увеличенным хешрейтом по сравнению с воздушно-охлаждаемыми аналогами. При хешрейте 198 TH/s и энергопотреблении 5445W, майнер показывает энергоэффективность на уровне 27.5 J/TH.
            </p>
            <p>
              <strong>Преимущества жидкостного охлаждения:</strong>
            </p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Более эффективный отвод тепла от электронных компонентов</li>
              <li>Значительное снижение уровня шума по сравнению с воздушным охлаждением</li>
              <li>Увеличение срока службы майнера</li>
              <li>Возможность более плотного размещения оборудования</li>
              <li>Лучшая защита от пыли и внешних факторов</li>
            </ul>
            <p>
              <strong>Комплектация:</strong>
            </p>
            <ul className="list-disc pl-5 space-y-1">
              <li>ASIC-майнер Antminer S19 Pro+ Hyd</li>
              <li>Комплект для подключения к системе жидкостного охлаждения</li>
              <li>Кабель питания</li>
              <li>Кабель Ethernet</li>
              <li>Документация</li>
            </ul>
            <div className="bg-blue-50 p-4 rounded-lg mt-6 dark:bg-blue-900/20">
              <div className="flex">
                <Info className="h-5 w-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0 dark:text-blue-400" />
                <div>
                  <h3 className="font-medium text-blue-800 dark:text-blue-300">Примечание по установке</h3>
                  <p className="text-blue-700 text-sm dark:text-blue-300">
                    Для работы данного майнера требуется система жидкостного охлаждения. Мы предлагаем комплексные решения
                    по установке и настройке системы жидкостного охлаждения. Для получения
                    консультации обратитесь к нашим специалистам.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="specifications" className="pt-6">
          <div className="overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
              <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-900 dark:divide-gray-700">
                {minerData.specifications.map((spec, index) => (
                  <tr key={index} className={index % 2 === 0 ? 'bg-gray-50 dark:bg-gray-800/50' : ''}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white w-1/3">
                      {spec.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                      {spec.value}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </TabsContent>

        <TabsContent value="reviews" className="pt-6">
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <MessageSquare className="h-12 w-12 text-gray-300 mb-4 dark:text-gray-600" />
            <h3 className="text-lg font-medium mb-2 dark:text-white">Отзывов пока нет</h3>
            <p className="text-gray-500 max-w-md mb-6 dark:text-gray-400">
              Будьте первым, кто оставит отзыв об этом товаре и поделится своим опытом использования с другими покупателями.
            </p>
            <Button className="bg-green-500 hover:bg-green-600 text-white">
              Оставить отзыв
            </Button>
          </div>
        </TabsContent>
      </Tabs>

      {/* Related Products */}
      <div className="mt-12">
        <h2 className="text-2xl font-bold mb-6 dark:text-white">Похожие товары</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {minerData.relatedProducts.map((product) => (
            <Card key={product.slug} className="overflow-hidden group border-gray-200 hover:border-green-500 transition-colors dark:bg-gray-800 dark:border-gray-700">
              <CardContent className="p-0">
                <div className="relative pt-[75%] bg-gray-100 dark:bg-gray-900 overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Image
                      src={product.image}
                      alt={product.name}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="absolute top-2 right-2">
                    <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full dark:bg-green-900 dark:text-green-200">
                      {product.status}
                    </span>
                  </div>
                  <Button variant="ghost" size="icon" className="absolute top-2 left-2 h-8 w-8 rounded-full bg-white/80 hover:bg-white shadow">
                    <Heart className="h-4 w-4" />
                  </Button>
                </div>
                <div className="p-4 dark:bg-gray-800">
                  <Link href={`/asic-miners/${product.slug}`} className="block">
                    <h3 className="font-medium text-lg mb-2 line-clamp-2 group-hover:text-green-500 dark:text-white">{product.name}</h3>
                  </Link>
                  <p className="font-bold text-lg dark:text-white">{product.price}</p>
                  <Button className="w-full mt-3 bg-green-500 hover:bg-green-600 text-white">
                    В корзину
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
