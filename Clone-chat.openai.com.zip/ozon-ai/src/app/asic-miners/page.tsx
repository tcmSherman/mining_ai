import Image from "next/image";
import Link from "next/link";
import { Metadata } from "next";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  FilterX,
  SlidersHorizontal,
  Heart,
  ShoppingCart,
  CircleCheck,
  Info,
  ChevronDown,
  Cpu,
  Zap,
  Sparkles,
  AlertCircle,
} from "lucide-react";

export const metadata: Metadata = {
  title: "ASIC-майнеры для майнинга Bitcoin и других криптовалют | MiningTech",
  description: "Большой выбор ASIC-майнеров с официальной гарантией. Доставка по всей России. Техническая поддержка и сервисное обслуживание.",
};

// Mockup data for miners
const minersData = [
  {
    id: 1,
    slug: "antminer-s19-pro-hyd",
    name: "Antminer S19 Pro+ Hyd (198 Th/s)",
    image: "/antminer-s19-pro.png",
    price: "1 590 000 ₽",
    oldPrice: "1 750 000 ₽",
    discount: "10%",
    status: "В наличии",
    algorithm: "SHA-256",
    hashrate: "198 Th/s",
    power: "5445W",
    efficiency: "27.5 J/Th",
    isTopSeller: true,
    isNew: false
  },
  {
    id: 2,
    slug: "antminer-s19j-pro",
    name: "Bitmain Antminer S19j Pro (104 Th/s)",
    image: "/antminer-s19j-pro.png",
    price: "760 000 ₽",
    oldPrice: "",
    discount: "",
    status: "В наличии",
    algorithm: "SHA-256",
    hashrate: "104 Th/s",
    power: "3068W",
    efficiency: "29.5 J/Th",
    isTopSeller: true,
    isNew: false
  },
  {
    id: 3,
    slug: "whatsminer-m50s",
    name: "WhatsMiner M50S (126 Th/s)",
    image: "/whatsminer-m50s.png",
    price: "895 000 ₽",
    oldPrice: "",
    discount: "",
    status: "Предзаказ",
    algorithm: "SHA-256",
    hashrate: "126 Th/s",
    power: "3472W",
    efficiency: "27.6 J/Th",
    isTopSeller: false,
    isNew: true
  },
  {
    id: 4,
    slug: "avalon-a1366",
    name: "Avalon A1366 (90 Th/s)",
    image: "/avalon-a1366.png",
    price: "580 000 ₽",
    oldPrice: "620 000 ₽",
    discount: "7%",
    status: "В наличии",
    algorithm: "SHA-256",
    hashrate: "90 Th/s",
    power: "3420W",
    efficiency: "38 J/Th",
    isTopSeller: false,
    isNew: false
  },
  {
    id: 5,
    slug: "antminer-s19-xp",
    name: "Antminer S19 XP (140 Th/s)",
    image: "/antminer-s19-pro.png", // Reusing image for demo
    price: "1 120 000 ₽",
    oldPrice: "",
    discount: "",
    status: "В наличии",
    algorithm: "SHA-256",
    hashrate: "140 Th/s",
    power: "3360W",
    efficiency: "21.5 J/Th",
    isTopSeller: true,
    isNew: false
  },
  {
    id: 6,
    slug: "whatsminer-m30s++",
    name: "WhatsMiner M30S++ (112 Th/s)",
    image: "/whatsminer-m50s.png", // Reusing image for demo
    price: "690 000 ₽",
    oldPrice: "750 000 ₽",
    discount: "8%",
    status: "В наличии",
    algorithm: "SHA-256",
    hashrate: "112 Th/s",
    power: "3472W",
    efficiency: "31 J/Th",
    isTopSeller: false,
    isNew: false
  },
  {
    id: 7,
    slug: "antminer-l7",
    name: "Antminer L7 (9.5 Gh/s)",
    image: "/antminer-s19j-pro.png", // Reusing image for demo
    price: "980 000 ₽",
    oldPrice: "",
    discount: "",
    status: "В наличии",
    algorithm: "Scrypt",
    hashrate: "9.5 Gh/s",
    power: "3425W",
    efficiency: "0.36 J/Mh",
    isTopSeller: false,
    isNew: false
  },
  {
    id: 8,
    slug: "antminer-e9",
    name: "Antminer E9 Pro (4.8 Gh/s)",
    image: "/avalon-a1366.png", // Reusing image for demo
    price: "1 250 000 ₽",
    oldPrice: "",
    discount: "",
    status: "Предзаказ",
    algorithm: "EtHash",
    hashrate: "4.8 Gh/s",
    power: "2790W",
    efficiency: "0.58 J/Mh",
    isTopSeller: false,
    isNew: true
  },
  {
    id: 9,
    slug: "antminer-s21-pro",
    name: "Bitmain Antminer S21 Pro (200 Th/s)",
    image: "/antminer-s19-pro.png", // Reusing image for now
    price: "1 950 000 ₽",
    oldPrice: "",
    discount: "",
    status: "Предзаказ",
    algorithm: "SHA-256",
    hashrate: "200 Th/s",
    power: "3400W",
    efficiency: "17.0 J/Th",
    isTopSeller: false,
    isNew: true
  },
  {
    id: 10,
    slug: "antminer-s21",
    name: "Bitmain Antminer S21 (185 Th/s)",
    image: "/antminer-s19j-pro.png", // Reusing image for now
    price: "1 750 000 ₽",
    oldPrice: "",
    discount: "",
    status: "Предзаказ",
    algorithm: "SHA-256",
    hashrate: "185 Th/s",
    power: "3450W",
    efficiency: "18.7 J/Th",
    isTopSeller: false,
    isNew: true
  },
  {
    id: 11,
    slug: "antminer-t21",
    name: "Bitmain Antminer T21 (170 Th/s)",
    image: "/antminer-s19-pro.png", // Reusing image for now
    price: "1 420 000 ₽",
    oldPrice: "1 550 000 ₽",
    discount: "9%",
    status: "В наличии",
    algorithm: "SHA-256",
    hashrate: "170 Th/s",
    power: "3400W",
    efficiency: "20.0 J/Th",
    isTopSeller: false,
    isNew: true
  }
];

export default function AsicMinersPage() {
  return (
    <div className="space-y-8">
      {/* Page header */}
      <div>
        <h1 className="text-3xl font-bold mb-3 dark:text-white">ASIC-майнеры</h1>
        <p className="text-gray-600 max-w-3xl dark:text-gray-300">
          Специализированные устройства для эффективного майнинга криптовалют.
          У нас представлены только оригинальные ASIC-майнеры от ведущих производителей
          с официальной гарантией.
        </p>
      </div>

      {/* Content grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Filters sidebar */}
        <div className="space-y-6 lg:sticky lg:top-24 lg:self-start">
          <Card className="dark:bg-gray-800 dark:border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold text-lg dark:text-white">Фильтры</h2>
                <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-gray-200">
                  <FilterX className="h-4 w-4 mr-1" />
                  Сбросить
                </Button>
              </div>

              <div className="space-y-6">
                {/* Price range */}
                <div>
                  <h3 className="text-sm font-medium mb-3 dark:text-gray-200">Цена, ₽</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Input
                        type="number"
                        placeholder="от"
                        className="dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                      />
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder="до"
                        className="dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                      />
                    </div>
                  </div>
                </div>

                {/* Availability */}
                <div>
                  <h3 className="text-sm font-medium mb-3 dark:text-gray-200">Наличие</h3>
                  <div className="space-y-2">
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input type="checkbox" className="rounded text-green-500 focus:ring-green-500 dark:bg-gray-700" defaultChecked />
                      <span className="text-gray-700 dark:text-gray-300">В наличии</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input type="checkbox" className="rounded text-green-500 focus:ring-green-500 dark:bg-gray-700" />
                      <span className="text-gray-700 dark:text-gray-300">Предзаказ</span>
                    </label>
                  </div>
                </div>

                {/* Mining algorithm */}
                <div>
                  <h3 className="text-sm font-medium mb-3 dark:text-gray-200">Алгоритм майнинга</h3>
                  <div className="space-y-2">
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input type="checkbox" className="rounded text-green-500 focus:ring-green-500 dark:bg-gray-700" defaultChecked />
                      <span className="text-gray-700 dark:text-gray-300">SHA-256 (Bitcoin)</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input type="checkbox" className="rounded text-green-500 focus:ring-green-500 dark:bg-gray-700" />
                      <span className="text-gray-700 dark:text-gray-300">Scrypt (Litecoin)</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input type="checkbox" className="rounded text-green-500 focus:ring-green-500 dark:bg-gray-700" />
                      <span className="text-gray-700 dark:text-gray-300">EtHash (Ethereum)</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input type="checkbox" className="rounded text-green-500 focus:ring-green-500 dark:bg-gray-700" />
                      <span className="text-gray-700 dark:text-gray-300">Equihash (Zcash)</span>
                    </label>
                  </div>
                </div>

                {/* Manufacturer */}
                <div>
                  <h3 className="text-sm font-medium mb-3 dark:text-gray-200">Производитель</h3>
                  <div className="space-y-2">
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input type="checkbox" className="rounded text-green-500 focus:ring-green-500 dark:bg-gray-700" defaultChecked />
                      <span className="text-gray-700 dark:text-gray-300">Bitmain</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input type="checkbox" className="rounded text-green-500 focus:ring-green-500 dark:bg-gray-700" defaultChecked />
                      <span className="text-gray-700 dark:text-gray-300">MicroBT</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input type="checkbox" className="rounded text-green-500 focus:ring-green-500 dark:bg-gray-700" defaultChecked />
                      <span className="text-gray-700 dark:text-gray-300">Canaan</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input type="checkbox" className="rounded text-green-500 focus:ring-green-500 dark:bg-gray-700" />
                      <span className="text-gray-700 dark:text-gray-300">Innosilicon</span>
                    </label>
                  </div>
                </div>

                {/* Hashrate range */}
                <div>
                  <h3 className="text-sm font-medium mb-3 dark:text-gray-200">Хешрейт для SHA-256</h3>
                  <div className="space-y-2">
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input type="checkbox" className="rounded text-green-500 focus:ring-green-500 dark:bg-gray-700" />
                      <span className="text-gray-700 dark:text-gray-300">до 90 Th/s</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input type="checkbox" className="rounded text-green-500 focus:ring-green-500 dark:bg-gray-700" defaultChecked />
                      <span className="text-gray-700 dark:text-gray-300">90-120 Th/s</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input type="checkbox" className="rounded text-green-500 focus:ring-green-500 dark:bg-gray-700" defaultChecked />
                      <span className="text-gray-700 dark:text-gray-300">120-150 Th/s</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input type="checkbox" className="rounded text-green-500 focus:ring-green-500 dark:bg-gray-700" defaultChecked />
                      <span className="text-gray-700 dark:text-gray-300">более 150 Th/s</span>
                    </label>
                  </div>
                </div>

                <Button className="w-full bg-green-500 hover:bg-green-600 text-white">
                  <SlidersHorizontal className="h-4 w-4 mr-2" />
                  Применить фильтры
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="dark:bg-gray-800 dark:border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-start">
                <Info className="h-5 w-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0 dark:text-blue-400" />
                <div>
                  <h3 className="font-medium mb-2 dark:text-white">Помощь с выбором</h3>
                  <p className="text-gray-600 text-sm mb-4 dark:text-gray-300">
                    Не знаете, какой ASIC-майнер подойдет именно вам? Наш Mining Assistant поможет подобрать оптимальное решение.
                  </p>
                  <Link href="/mining-assistant">
                    <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                      Консультация
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main content */}
        <div className="lg:col-span-3 space-y-6">
          {/* Sort and filter controls */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 bg-gray-50 rounded-lg dark:bg-gray-800">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm text-gray-500 dark:text-gray-400">Найдено: {minersData.length}</span>
              <div className="flex items-center">
                <span className="text-sm text-gray-500 mr-2 dark:text-gray-400">Сортировать:</span>
                <Select defaultValue="popular">
                  <SelectTrigger className="w-[180px] h-9 border-gray-300 bg-white dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                    <SelectValue placeholder="По популярности" />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-800 dark:border-gray-700">
                    <SelectGroup>
                      <SelectItem value="popular">По популярности</SelectItem>
                      <SelectItem value="price-asc">По цене (сначала дешевле)</SelectItem>
                      <SelectItem value="price-desc">По цене (сначала дороже)</SelectItem>
                      <SelectItem value="hashrate">По хешрейту</SelectItem>
                      <SelectItem value="efficiency">По энергоэффективности</SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="outline" size="sm" className="border-gray-300 dark:border-gray-600 dark:text-gray-300">
                <Cpu className="h-4 w-4 mr-1" />
                SHA-256
                <ChevronDown className="h-3 w-3 ml-1" />
              </Button>
              <Button variant="outline" size="sm" className="border-gray-300 dark:border-gray-600 dark:text-gray-300">
                <Zap className="h-4 w-4 mr-1" />
                Хешрейт
                <ChevronDown className="h-3 w-3 ml-1" />
              </Button>
            </div>
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
            {minersData.map((miner) => (
              <Card key={miner.id} className="overflow-hidden group border-gray-200 hover:border-green-500 transition-colors dark:bg-gray-800 dark:border-gray-700">
                <CardContent className="p-0">
                  <div className="relative pt-[75%] bg-gray-100 dark:bg-gray-900 overflow-hidden">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Image
                        src={miner.image}
                        alt={miner.name}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="absolute top-2 right-2">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        miner.status === "В наличии"
                          ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                          : "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200"
                      }`}>
                        {miner.status}
                      </span>
                    </div>
                    <div className="absolute top-2 left-2">
                      {miner.isNew && (
                        <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium mr-1 dark:bg-blue-900 dark:text-blue-200">
                          Новинка
                        </span>
                      )}
                      {miner.isTopSeller && (
                        <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded-full text-xs font-medium dark:bg-purple-900 dark:text-purple-200">
                          Хит продаж
                        </span>
                      )}
                    </div>
                    <Button variant="ghost" size="icon" className="absolute top-10 left-2 h-8 w-8 rounded-full bg-white/80 hover:bg-white shadow">
                      <Heart className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="p-4 dark:bg-gray-800">
                    <Link href={`/asic-miners/${miner.slug}`} className="block">
                      <h3 className="font-medium text-lg mb-2 line-clamp-2 group-hover:text-green-500 dark:text-white">{miner.name}</h3>
                    </Link>

                    <div className="space-y-1 mb-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600 text-sm dark:text-gray-400">Алгоритм:</span>
                        <span className="font-medium dark:text-gray-200">{miner.algorithm}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 text-sm dark:text-gray-400">Хешрейт:</span>
                        <span className="font-medium dark:text-gray-200">{miner.hashrate}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 text-sm dark:text-gray-400">Потребление:</span>
                        <span className="font-medium dark:text-gray-200">{miner.power}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 text-sm dark:text-gray-400">Эффективность:</span>
                        <span className="font-medium dark:text-gray-200">{miner.efficiency}</span>
                      </div>
                    </div>

                    <div className="flex justify-between items-end mb-3">
                      <div>
                        {miner.oldPrice && (
                          <p className="text-gray-500 line-through text-sm dark:text-gray-400">{miner.oldPrice}</p>
                        )}
                        <p className="text-xl font-bold dark:text-white">{miner.price}</p>
                        {miner.discount && (
                          <span className="inline-block bg-red-100 text-red-800 text-xs font-medium px-2 py-0.5 rounded dark:bg-red-900 dark:text-red-200">
                            -{miner.discount}
                          </span>
                        )}
                      </div>
                      {miner.status === "В наличии" && (
                        <div className="flex items-center text-green-600 text-sm dark:text-green-400">
                          <CircleCheck className="h-4 w-4 mr-1" />
                          <span>Есть в наличии</span>
                        </div>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <Button className="flex-1 bg-green-500 hover:bg-green-600 text-white">
                        <ShoppingCart className="h-4 w-4 mr-2" />
                        В корзину
                      </Button>
                      <Link href={`/asic-miners/${miner.slug}`} className="block">
                        <Button variant="outline" className="border-gray-200 hover:border-green-500 hover:text-green-500 dark:border-gray-700 dark:text-gray-300 dark:hover:text-green-500">
                          Подробнее
                        </Button>
                      </Link>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Info banner */}
          <div className="bg-blue-50 p-6 rounded-lg mt-8 dark:bg-blue-900/20">
            <div className="flex">
              <AlertCircle className="h-6 w-6 text-blue-600 mr-4 flex-shrink-0 dark:text-blue-400" />
              <div>
                <h3 className="font-semibold text-blue-800 mb-2 dark:text-blue-300">Заказать ASIC-майнер в любой конфигурации</h3>
                <p className="text-blue-700 mb-4 dark:text-blue-300">
                  Помимо представленных моделей, у нас вы можете заказать любую конфигурацию и количество ASIC-майнеров напрямую
                  с заводов-производителей. Для получения коммерческого предложения свяжитесь с нами.
                </p>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                  Связаться с нами
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
