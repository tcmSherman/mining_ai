import "@/styles/globals.css";
import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { Toaster } from "sonner";
import Header from "@/components/header";
import Footer from "@/components/footer";

const inter = Inter({ subsets: ["latin", "cyrillic"] });

export const metadata: Metadata = {
  title: "MiningTech - Надежные ASIC-майнеры и комплектующие",
  description: "Интернет-магазин ASIC-майнеров, комплектующих и оборудования для майнинга криптовалют. Официальная гарантия, быстрая доставка.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ru">
      <body className={inter.className}>
        <div className="flex min-h-screen flex-col">
          <Header />
          <main className="flex-1 container mx-auto py-4 px-4 md:px-6">
            {children}
          </main>
          <Footer />
        </div>
        <Toaster position="top-center" />
      </body>
    </html>
  );
}
