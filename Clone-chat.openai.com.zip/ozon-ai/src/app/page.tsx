import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ArrowRight,
  Cpu,
  Zap,
  Thermometer,
  Settings,
  Wrench,
  Coins,
  ChevronRight,
  DollarSign,
  MessageSquare,
  SendHorizonal,
  ArrowDown,
} from "lucide-react";
import MiningAssistant from "@/components/mining-assistant";

export default function HomePage() {
  return (
    <div className="space-y-12">
      {/* Hero Section with Mining Assistant */}
      <section className="relative overflow-hidden rounded-xl bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 py-12 px-6">
        <div className="text-center pt-10 mb-12">
          <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl mb-6">
            Первый маркетплейс майнинг-оборудования <br />с <span className="bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">AI-консультантом</span>
          </h1>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto mb-10">
            Получите квалифицированную консультацию по выбору ASIC-майнеров и оборудования для майнинга. Наш ИИ-ассистент поможет подобрать оптимальное решение и рассчитать доходность.
          </p>
          <div className="flex justify-center">
            <ArrowDown className="h-8 w-8 text-green-500 animate-bounce" />
          </div>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="bg-gray-800/40 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6 shadow-2xl">
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold text-white mb-2">Mining Assistant</h2>
              <p className="text-gray-300">
                Задайте вопрос о майнинге криптовалют, выборе оборудования или расчете доходности
              </p>
            </div>

            <MiningAssistant fullHeight />

            <div className="mt-4 text-center">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                {[
                  "Какой ASIC-майнер выбрать для майнинга Bitcoin?",
                  "Как рассчитать окупаемость майнера?",
                  "Что такое иммерсионное охлаждение?"
                ].map((question, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className="text-left justify-start border-gray-700 hover:border-green-500 text-gray-200 text-sm"
                  >
                    <MessageSquare className="h-4 w-4 mr-2 text-green-500 flex-shrink-0" />
                    <span className="truncate">{question}</span>
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Decorative elements */}
        <div className="absolute -bottom-16 -left-16 w-64 h-64 bg-green-500 rounded-full opacity-10 blur-3xl"></div>
        <div className="absolute -top-16 -right-16 w-64 h-64 bg-blue-500 rounded-full opacity-10 blur-3xl"></div>
      </section>

      {/* Why Choose Us */}
      <section className="py-8">
        <h2 className="text-2xl font-bold text-center mb-8 dark:text-white">Почему стоит выбрать наш маркетплейс</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="border-gray-200 dark:bg-gray-800 dark:border-gray-700">
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center gap-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center dark:bg-green-900">
                  <MessageSquare className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
                <h3 className="text-xl font-semibold dark:text-white">ИИ-консультант</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Уникальный ИИ-ассистент поможет подобрать оптимальное оборудование и ответит на все вопросы о майнинге
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-gray-200 dark:bg-gray-800 dark:border-gray-700">
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center gap-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center dark:bg-green-900">
                  <Cpu className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
                <h3 className="text-xl font-semibold dark:text-white">Официальные поставки</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Работаем напрямую с производителями. Предоставляем официальную гарантию на всё оборудование
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-gray-200 dark:bg-gray-800 dark:border-gray-700">
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center gap-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center dark:bg-green-900">
                  <Settings className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
                <h3 className="text-xl font-semibold dark:text-white">Техническая поддержка</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Поможем с настройкой и подключением. Консультируем по всем вопросам 24/7
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-gray-200 dark:bg-gray-800 dark:border-gray-700">
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center gap-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center dark:bg-green-900">
                  <Coins className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
                <h3 className="text-xl font-semibold dark:text-white">Гибкие условия оплаты</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Принимаем оплату в рублях и криптовалютой. Возможна рассрочка платежа
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Popular models */}
      <section className="py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Популярные модели ASIC-майнеров</h2>
          <Link href="/asic-miners" className="text-green-500 hover:text-green-600 font-medium flex items-center">
            Смотреть все <ChevronRight className="ml-1 h-4 w-4" />
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {popularMiners.map((miner, index) => (
            <Card key={index} className="overflow-hidden group border-gray-200 hover:border-green-500 transition-colors dark:bg-gray-800 dark:border-gray-700">
              <CardContent className="p-0">
                <div className="relative pt-[75%] bg-gray-100 dark:bg-gray-900 overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Image
                      src={miner.image}
                      alt={miner.name}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="absolute top-2 right-2">
                    <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full dark:bg-green-900 dark:text-green-200">
                      {miner.status}
                    </span>
                  </div>
                </div>
                <div className="p-4 dark:bg-gray-800">
                  <h3 className="font-medium text-lg mb-2 line-clamp-2 group-hover:text-green-500 dark:text-white">{miner.name}</h3>
                  <div className="space-y-2 mb-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600 text-sm dark:text-gray-400">Хешрейт:</span>
                      <span className="font-medium dark:text-gray-200">{miner.hashrate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600 text-sm dark:text-gray-400">Потребление:</span>
                      <span className="font-medium dark:text-gray-200">{miner.power}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600 text-sm dark:text-gray-400">Алгоритм:</span>
                      <span className="font-medium dark:text-gray-200">{miner.algorithm}</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center mt-4">
                    <span className="text-xl font-bold dark:text-white">{miner.price}</span>
                    <Button className="bg-green-500 hover:bg-green-600 text-white">В корзину</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="py-8">
        <h2 className="text-2xl font-bold mb-6">Категории оборудования</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <Link href="/asic-miners">
            <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer hover:border-green-500 dark:hover:border-green-500 dark:bg-gray-800 dark:border-gray-700">
              <CardContent className="p-6 flex flex-col h-full">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4 dark:bg-green-900">
                  <Cpu className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
                <h3 className="text-xl font-bold mb-2 dark:text-white">ASIC-майнеры</h3>
                <p className="text-gray-600 mb-4 flex-grow dark:text-gray-400">
                  Специализированные устройства для майнинга различных криптовалют.
                </p>
                <span className="text-green-500 font-medium flex items-center">
                  Перейти <ArrowRight className="ml-1 h-4 w-4" />
                </span>
              </CardContent>
            </Card>
          </Link>

          <Link href="/power-supplies">
            <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer hover:border-green-500 dark:hover:border-green-500 dark:bg-gray-800 dark:border-gray-700">
              <CardContent className="p-6 flex flex-col h-full">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4 dark:bg-green-900">
                  <Zap className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
                <h3 className="text-xl font-bold mb-2 dark:text-white">Блоки питания</h3>
                <p className="text-gray-600 mb-4 flex-grow dark:text-gray-400">
                  Надежные блоки питания различной мощности для майнинг-оборудования.
                </p>
                <span className="text-green-500 font-medium flex items-center">
                  Перейти <ArrowRight className="ml-1 h-4 w-4" />
                </span>
              </CardContent>
            </Card>
          </Link>

          <Link href="/cooling-systems">
            <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer hover:border-green-500 dark:hover:border-green-500 dark:bg-gray-800 dark:border-gray-700">
              <CardContent className="p-6 flex flex-col h-full">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4 dark:bg-green-900">
                  <Thermometer className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
                <h3 className="text-xl font-bold mb-2 dark:text-white">Системы охлаждения</h3>
                <p className="text-gray-600 mb-4 flex-grow dark:text-gray-400">
                  Эффективные системы для охлаждения майнинг-ферм и отдельных устройств.
                </p>
                <span className="text-green-500 font-medium flex items-center">
                  Перейти <ArrowRight className="ml-1 h-4 w-4" />
                </span>
              </CardContent>
            </Card>
          </Link>
        </div>
      </section>

      {/* CTA */}
      <section className="py-8">
        <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-xl p-8 text-white text-center">
          <h2 className="text-3xl font-bold mb-4">Начните майнинг с профессиональной консультацией</h2>
          <p className="text-lg text-gray-300 mb-6 max-w-2xl mx-auto">
            Наш ИИ-ассистент всегда готов помочь с выбором оборудования, расчетом доходности и ответить на любые ваши вопросы о майнинге
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-green-500 hover:bg-green-600 text-white">
              <MessageSquare className="mr-2 h-5 w-5" />
              Задать вопрос ассистенту
            </Button>
            <Button variant="outline" size="lg" className="bg-gray-800 hover:bg-gray-700 text-white border-gray-700">
              Перейти в каталог
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}

// Образцы данных для отображения
const popularMiners = [
  {
    name: "Bitmain Antminer S21 Pro (200 Th/s)",
    image: "/antminer-s19-pro.png", // Using S19 Pro image as a placeholder
    hashrate: "200 Th/s",
    power: "3400W",
    algorithm: "SHA-256",
    price: "1 950 000 ₽",
    status: "Предзаказ"
  },
  {
    name: "Antminer T21 (170 Th/s)",
    image: "/antminer-s19-pro.png", // Using S19 Pro image as a placeholder
    hashrate: "170 Th/s",
    power: "3400W",
    algorithm: "SHA-256",
    price: "1 420 000 ₽",
    status: "В наличии"
  },
  {
    name: "Antminer S19 Pro+ Hyd (198 Th/s)",
    image: "/antminer-s19-pro.png",
    hashrate: "198 Th/s",
    power: "5445W",
    algorithm: "SHA-256",
    price: "1 590 000 ₽",
    status: "В наличии"
  },
  {
    name: "WhatsMiner M50S (126 Th/s)",
    image: "/whatsminer-m50s.png",
    hashrate: "126 Th/s",
    power: "3472W",
    algorithm: "SHA-256",
    price: "895 000 ₽",
    status: "Предзаказ"
  }
];
