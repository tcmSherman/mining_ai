import { Metadata } from "next";
import MiningAssistant from "@/components/mining-assistant";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { MessageSquare, Calculator, Book, ChevronRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Mining Assistant - Ваш консультант по майнингу | MiningTech",
  description: "Интеллектуальный помощник для выбора ASIC-майнеров, расчета доходности и получения советов по майнингу криптовалют.",
};

export default function MiningAssistantPage() {
  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold mb-2 dark:text-white">Mining Assistant</h1>
          <p className="text-gray-600 max-w-2xl dark:text-gray-400">
            Ваш персональный консультант по майнингу. Задавайте вопросы о выборе оборудования,
            настройке майнеров, доходности и любых других аспектах майнинга криптовалют.
          </p>
        </div>
        <Link href="/asic-miners">
          <Button className="bg-green-500 hover:bg-green-600 text-white">
            Перейти в каталог ASIC-майнеров <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </Link>
      </div>

      <Tabs defaultValue="chat" className="w-full">
        <TabsList className="border-b w-full justify-start rounded-none gap-4 px-0 h-auto">
          <TabsTrigger
            value="chat"
            className="rounded-t-lg rounded-b-none border-b-2 border-transparent data-[state=active]:border-green-500 data-[state=active]:text-green-500 h-10 pb-2"
          >
            <MessageSquare className="h-4 w-4 mr-2" />
            Чат с ассистентом
          </TabsTrigger>
          <TabsTrigger
            value="calculator"
            className="rounded-t-lg rounded-b-none border-b-2 border-transparent data-[state=active]:border-green-500 data-[state=active]:text-green-500 h-10 pb-2"
          >
            <Calculator className="h-4 w-4 mr-2" />
            Калькулятор доходности
          </TabsTrigger>
          <TabsTrigger
            value="library"
            className="rounded-t-lg rounded-b-none border-b-2 border-transparent data-[state=active]:border-green-500 data-[state=active]:text-green-500 h-10 pb-2"
          >
            <Book className="h-4 w-4 mr-2" />
            Библиотека знаний
          </TabsTrigger>
        </TabsList>

        <TabsContent value="chat" className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              <MiningAssistant fullHeight />
            </div>

            <div className="space-y-6">
              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardHeader>
                  <CardTitle>Популярные вопросы</CardTitle>
                  <CardDescription>Выберите один из популярных вопросов или задайте свой</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    "Как выбрать ASIC-майнер для Bitcoin?",
                    "Какой блок питания нужен для Antminer S19 Pro?",
                    "Как настроить Antminer S19j Pro?",
                    "Какой срок окупаемости у современных майнеров?",
                    "Как организовать охлаждение в майнинг-ферме?",
                    "Сколько можно заработать на майнинге Bitcoin сейчас?"
                  ].map((question, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className="w-full justify-start text-left h-auto py-2 border-gray-200 hover:border-green-500 dark:border-gray-700 dark:hover:border-green-500 dark:text-gray-300"
                    >
                      <MessageSquare className="h-4 w-4 mr-2 flex-shrink-0 text-green-500" />
                      <span>{question}</span>
                    </Button>
                  ))}
                </CardContent>
              </Card>

              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardHeader>
                  <CardTitle>Рекомендуемые статьи</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Link href="#" className="block hover:bg-gray-50 p-3 rounded-lg dark:hover:bg-gray-700">
                    <h3 className="font-medium text-green-500">Гайд для начинающих: с чего начать майнинг</h3>
                    <p className="text-sm text-gray-600 mt-1 dark:text-gray-400">Полное руководство для тех, кто хочет начать майнинг криптовалют</p>
                  </Link>
                  <Link href="#" className="block hover:bg-gray-50 p-3 rounded-lg dark:hover:bg-gray-700">
                    <h3 className="font-medium text-green-500">Сравнение ASIC-майнеров 2025 года</h3>
                    <p className="text-sm text-gray-600 mt-1 dark:text-gray-400">Подробное сравнение современных моделей ASIC-майнеров</p>
                  </Link>
                  <Link href="#" className="block hover:bg-gray-50 p-3 rounded-lg dark:hover:bg-gray-700">
                    <h3 className="font-medium text-green-500">Особенности иммерсионного охлаждения</h3>
                    <p className="text-sm text-gray-600 mt-1 dark:text-gray-400">Преимущества и недостатки погружного охлаждения для майнеров</p>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="calculator" className="pt-6">
          <Card className="dark:bg-gray-800 dark:border-gray-700">
            <CardHeader>
              <CardTitle>Калькулятор доходности</CardTitle>
              <CardDescription>
                Расчёт примерной доходности майнинга на разных ASIC-майнерах
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="py-8 text-center">
                <p className="text-gray-500 mb-4 dark:text-gray-400">Функционал калькулятора доходности находится в разработке</p>
                <p className="text-gray-500 mb-4 dark:text-gray-400">Задайте вопрос о доходности майнинга в чате с ассистентом</p>
                <Button className="bg-green-500 hover:bg-green-600 text-white mt-4">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Спросить у ассистента
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="library" className="pt-6">
          <Card className="dark:bg-gray-800 dark:border-gray-700">
            <CardHeader>
              <CardTitle>Библиотека знаний о майнинге</CardTitle>
              <CardDescription>
                Полезные материалы о майнинге криптовалют, ASIC-майнерах и оборудовании
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="py-8 text-center">
                <p className="text-gray-500 mb-4 dark:text-gray-400">Наша база знаний находится в процессе наполнения</p>
                <p className="text-gray-500 mb-4 dark:text-gray-400">В ближайшее время здесь появятся полезные материалы</p>
                <Button className="bg-green-500 hover:bg-green-600 text-white mt-4">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Задать вопрос ассистенту
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
