import Link from "next/link";
import { Separator } from "@/components/ui/separator";

export default function Footer() {
  return (
    <footer className="bg-gray-900 border-t border-gray-800 py-8 text-gray-300">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-semibold text-lg mb-3 text-white">MiningTech</h3>
            <p className="text-sm text-gray-400 mb-4">
              Ведущий поставщик ASIC-майнеров и оборудования для майнинга криптовалют. Официальная гарантия,
              техническая поддержка и консультация по выбору оборудования.
            </p>
            <div className="flex items-center gap-4">
              <Link href="#" className="text-gray-400 hover:text-green-500">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                </svg>
              </Link>
              <Link href="#" className="text-gray-400 hover:text-green-500">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                </svg>
              </Link>
              <Link href="#" className="text-gray-400 hover:text-green-500">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
                </svg>
              </Link>
              <Link href="#" className="text-gray-400 hover:text-green-500">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="m8 3 4 8 5-5 5 15H2L8 3z" />
                </svg>
              </Link>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-3 text-white">Покупателям</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="#" className="text-gray-400 hover:text-green-500">Как сделать заказ</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-green-500">Способы оплаты</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-green-500">Доставка и самовывоз</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-green-500">Гарантия и возврат</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-green-500">Часто задаваемые вопросы</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-3 text-white">Каталог</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="#" className="text-gray-400 hover:text-green-500">ASIC Майнеры</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-green-500">Блоки питания</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-green-500">Системы охлаждения</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-green-500">Контроллеры и мониторинг</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-green-500">Комплектующие и запчасти</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-green-500">Услуги ремонта и настройки</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-3 text-white">Контакты</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mt-1 flex-shrink-0 text-green-500"
                >
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                </svg>
                <span className="text-gray-400">8 800 123 45 67</span>
              </li>
              <li className="flex items-start gap-2">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mt-1 flex-shrink-0 text-green-500"
                >
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                  <polyline points="22,6 12,13 2,6" />
                </svg>
                <span className="text-gray-400">info@miningtech.ru</span>
              </li>
              <li className="flex items-start gap-2">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mt-1 flex-shrink-0 text-green-500"
                >
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                  <circle cx="12" cy="10" r="3" />
                </svg>
                <span className="text-gray-400">Москва, ул. Майнинговая, д. 123</span>
              </li>
              <li className="flex items-start gap-2">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mt-1 flex-shrink-0 text-green-500"
                >
                  <path d="M12 2a10 10 0 1 0 10 10H12V2Z" />
                  <path d="M20 2a10 10 0 0 1-8 11.3h0V12a10 10 0 0 0 10-10V2Z" />
                </svg>
                <span className="text-gray-400">График работы: Пн-Пт: 10:00-20:00</span>
              </li>
            </ul>
          </div>
        </div>

        <Separator className="my-6 bg-gray-800" />

        <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
          <div className="flex items-center gap-3">
            <img src="/bitcoin-logo.svg" alt="Bitcoin" width={24} height={24} className="opacity-70" />
            <img src="/ethereum-logo.svg" alt="Ethereum" width={20} height={20} className="opacity-70" />
            <img src="/litecoin-logo.svg" alt="Litecoin" width={24} height={24} className="opacity-70" />
            <span className="text-sm text-gray-500">Принимаем криптовалюты</span>
          </div>

          <p className="text-sm text-gray-500">
            © {new Date().getFullYear()} MiningTech. Все права защищены.
          </p>

          <div className="flex gap-4">
            <Link href="#" className="text-sm text-gray-500 hover:text-green-500">
              Условия использования
            </Link>
            <Link href="#" className="text-sm text-gray-500 hover:text-green-500">
              Политика конфиденциальности
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
