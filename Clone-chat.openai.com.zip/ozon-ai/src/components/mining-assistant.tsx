"use client";

import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MessageSquare, Send, ArrowDown, CircleHelp } from "lucide-react";
import { Avatar } from "@/components/ui/avatar";

type Message = {
  role: "user" | "assistant";
  content: string;
};

type MiningAssistantProps = {
  fullHeight?: boolean;
};

// Примеры предопределенных ответов для демонстрации функциональности
const predefinedResponses: Record<string, string> = {
  "привет": "Здравствуйте! Я ваш ассистент по майнингу криптовалют. Чем могу помочь?",
  "какой майнер": "Для выбора ASIC-майнера важно учитывать несколько факторов: алгоритм майнинга, хешрейт, энергоэффективность и бюджет. Для майнинга Bitcoin лучшими моделями на данный момент являются Antminer S21 Pro (200 Th/s), Antminer S21 (185 Th/s), Antminer T21 (170 Th/s) и Antminer S19 XP (140 Th/s). Могу рассказать подробнее о каждой модели или помочь с выбором под ваши конкретные условия.",
  "охлаждение": "Эффективное охлаждение ASIC-майнеров критически важно для их долговечности и стабильной работы. Существует несколько типов охлаждения:\n\n1. Воздушное охлаждение - стандартный и доступный вариант\n2. Жидкостное охлаждение - более эффективный, но сложный вариант\n3. Иммерсионное охлаждение - погружение оборудования в диэлектрическую жидкость, наиболее эффективный метод\n\nДля домашнего майнинга обычно достаточно хорошего воздушного охлаждения с дополнительными вентиляторами. Для промышленного майнинга рекомендуется жидкостное или иммерсионное охлаждение.",
  "доходность": "Доходность майнинга зависит от многих факторов: модели ASIC-майнера, стоимости электроэнергии, текущего курса криптовалюты и сложности сети. Например, Antminer S21 Pro (200 Th/s) при стоимости электроэнергии 5 руб/кВтч будет приносить примерно 2800-3200 рублей чистой прибыли в день при текущем курсе Bitcoin благодаря высокой энергоэффективности (17.0 J/Th).\n\nДля точного расчета рекомендую использовать специальные калькуляторы доходности. Могу помочь с расчетом для конкретной модели майнера и ваших условий.",
  "блок питания": "Выбор блока питания для ASIC-майнера очень важен. Блок питания должен обеспечивать стабильное электроснабжение и иметь запас мощности около 20-30% от потребления майнера.\n\nДля Antminer S21 Pro, потребляющего около 3400W, рекомендуется блок питания мощностью не менее 4500W. Лучше всего использовать специализированные БП для майнеров, такие как Bitmain APW9+, Power Supply Unit APW3++, или БП от SuperFlower.\n\nВажные характеристики при выборе БП:\n1. Достаточная мощность\n2. Высокий КПД (золотой или платиновый сертификат)\n3. Защита от перепадов напряжения\n4. Хорошее охлаждение",
  "настройка": "Настройка ASIC-майнера включает несколько этапов:\n\n1. Физическое подключение: соединение с блоком питания, подключение к интернету (обычно через Ethernet)\n\n2. Доступ к веб-интерфейсу:\n   - Найдите IP-адрес устройства через роутер\n   - Введите IP в браузере\n   - Войдите с стандартными учетными данными (обычно admin/admin или root/root)\n\n3. Базовая настройка:\n   - Смена пароля администратора\n   - Настройка пула для майнинга (введите URL пула, ваш логин/кошелек и пароль воркера)\n   - Настройка частоты (для опытных пользователей)\n\nМогу предоставить более подробную инструкцию для конкретной модели майнера.",
  "antminer": "Antminer - это линейка ASIC-майнеров от компании Bitmain, одного из ведущих производителей оборудования для майнинга. Самые популярные модели:\n\n1. Antminer S21 Pro (200 Th/s) - новейшая флагманская модель с рекордной энергоэффективностью 17.0 J/Th\n2. Antminer S21 (185 Th/s) - баланс производительности и энергоэффективности\n3. Antminer T21 (170 Th/s) - доступный майнер новой серии с эффективностью 20.0 J/Th\n4. Antminer S19 Pro+ Hyd (198 Th/s) - флагманская модель с жидкостным охлаждением\n5. Antminer S19j Pro (104 Th/s) - оптимальное соотношение цены и производительности\n\nВсе эти модели предназначены для майнинга Bitcoin (SHA-256). У нас в наличии есть все эти модели с официальной гарантией от производителя.",
  "whatsminer": "WhatsMiner - это серия ASIC-майнеров от компании MicroBT. Основные модели:\n\n1. WhatsMiner M50S (126 Th/s) - флагманская модель с хорошей энергоэффективностью\n2. WhatsMiner M30S++ (112 Th/s) - проверенная временем модель\n3. WhatsMiner M50 (114 Th/s) - обновленная версия с улучшенной энергоэффективностью\n\nМайнеры WhatsMiner отличаются высокой надежностью и хорошей системой охлаждения. Они обычно немного дешевле аналогичных моделей Antminer, но при этом имеют сопоставимые характеристики.",
  "s21": "Antminer S21 - это новая линейка высокоэффективных ASIC-майнеров от Bitmain для майнинга Bitcoin. Доступны две основные модели:\n\n1. Antminer S21 Pro (200 Th/s) - флагманская модель с рекордной энергоэффективностью 17.0 J/Th и потреблением 3400W\n2. Antminer S21 (185 Th/s) - стандартная модель с энергоэффективностью 18.7 J/Th и потреблением 3450W\n\nОбе модели имеют воздушное охлаждение и существенно превосходят предыдущую серию S19 по эффективности. Высокий хешрейт в сочетании с низким энергопотреблением делает их одними из самых рентабельных ASIC-майнеров на рынке. Срок окупаемости таких майнеров при текущем курсе Bitcoin может составлять от 8 до 12 месяцев.",
  "t21": "Antminer T21 (170 Th/s) - это новый доступный ASIC-майнер от Bitmain, который представляет собой более бюджетную альтернативу серии S21. Основные характеристики:\n\n- Хешрейт: 170 Th/s\n- Энергопотребление: 3400W\n- Энергоэффективность: 20.0 J/Th\n- Алгоритм: SHA-256 (Bitcoin)\n\nT21 имеет отличное соотношение цены и производительности, стоимость устройства - 1 420 000 ₽. Майнер оснащен воздушной системой охлаждения и имеет официальную гарантию 12 месяцев. По сравнению с предыдущей T-серией, T21 имеет значительно улучшенную энергоэффективность, что делает его привлекательным выбором для тех, кто ищет баланс между стоимостью устройства и доходностью."
};

export default function MiningAssistant({ fullHeight = false }: MiningAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Здравствуйте! Я Mining Assistant - ваш помощник по вопросам майнинга криптовалют. Могу помочь с выбором ASIC-майнеров, расчетом доходности, настройкой оборудования и ответить на другие вопросы о майнинге. Что вас интересует?"
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage = inputValue.trim();
    setMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setInputValue("");
    setIsLoading(true);

    // Имитация задержки ответа для реалистичности
    setTimeout(() => {
      // Поиск в предопределенных ответах по ключевым словам
      let response = "Извините, я не смог найти информацию по вашему запросу. Пожалуйста, уточните ваш вопрос или перефразируйте его. Я могу помочь с выбором ASIC-майнеров, расчетом доходности, настройкой и обслуживанием оборудования.";

      for (const [keyword, answer] of Object.entries(predefinedResponses)) {
        if (userMessage.toLowerCase().includes(keyword.toLowerCase())) {
          response = answer;
          break;
        }
      }

      setMessages(prev => [...prev, { role: "assistant", content: response }]);
      setIsLoading(false);
    }, 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Card className="border-gray-200 shadow-md overflow-hidden dark:border-gray-700 dark:bg-gray-800">
      <div className={`flex flex-col ${fullHeight ? "h-[600px]" : "h-[400px]"}`}>
        {/* Сообщения */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div className="flex items-start gap-3 max-w-[80%]">
                {message.role === "assistant" && (
                  <Avatar className="mt-1 bg-green-500 text-white">
                    <MessageSquare className="h-4 w-4" />
                  </Avatar>
                )}
                <div
                  className={`
                    p-3 rounded-lg
                    ${message.role === "user"
                      ? "bg-green-500 text-white rounded-tr-none"
                      : "bg-gray-100 dark:bg-gray-700 dark:text-white rounded-tl-none"
                    }
                  `}
                >
                  <p className="whitespace-pre-line">{message.content}</p>
                </div>
                {message.role === "user" && (
                  <Avatar className="mt-1 bg-gray-200 text-gray-700 dark:bg-gray-600 dark:text-gray-200">
                    <div className="text-xs font-bold">У</div>
                  </Avatar>
                )}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="flex items-start gap-3">
                <Avatar className="mt-1 bg-green-500 text-white">
                  <MessageSquare className="h-4 w-4" />
                </Avatar>
                <div className="p-3 rounded-lg bg-gray-100 dark:bg-gray-700 rounded-tl-none">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce dark:bg-gray-500"></div>
                    <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce [animation-delay:0.2s] dark:bg-gray-500"></div>
                    <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce [animation-delay:0.4s] dark:bg-gray-500"></div>
                  </div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Разделитель */}
        <div className="border-t border-gray-200 dark:border-gray-700"></div>

        {/* Ввод сообщения */}
        <div className="p-3 flex items-end">
          <div className="relative flex-1">
            <textarea
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder="Задайте вопрос о майнинге криптовалют..."
              className="w-full py-3 px-4 pr-12 resize-none rounded-lg border border-gray-300 focus:outline-none focus:border-green-500 min-h-[50px] max-h-[200px] overflow-auto dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
              rows={1}
              style={{ height: 'auto', maxHeight: '150px' }}
            />
            <Button
              onClick={handleSendMessage}
              disabled={isLoading}
              className="absolute right-2 bottom-2 p-2 h-auto bg-green-500 hover:bg-green-600 text-white rounded-full"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="px-3 pb-3 text-xs text-gray-500 flex justify-between items-center dark:text-gray-400">
          <div className="flex items-center gap-1">
            <CircleHelp className="h-3 w-3" />
            <span>Подсказка: попробуйте спросить о выборе блока питания или расчете доходности</span>
          </div>
          <Button
            size="sm"
            variant="ghost"
            className="h-6 px-2 text-gray-500 hover:text-green-500 hover:bg-transparent dark:text-gray-400 dark:hover:text-green-400"
            onClick={scrollToBottom}
          >
            <ArrowDown className="h-3 w-3 mr-1" />
            <span className="text-xs">Вниз</span>
          </Button>
        </div>
      </div>
    </Card>
  );
}
