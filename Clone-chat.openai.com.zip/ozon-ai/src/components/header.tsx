"use client";

import { Search } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ShoppingCart, User, Menu, MessageSquare, Cpu, Wrench, Settings } from "lucide-react";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-10 bg-gray-900 border-b border-gray-800">
      <div className="container mx-auto px-4 md:px-6 py-3">
        <div className="flex items-center justify-between">
          {/* Logo and brand */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center gap-2">
              <div className="relative w-9 h-9 bg-gradient-to-r from-purple-500 to-blue-600 rounded-full">
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-white">
                  <Cpu className="h-5 w-5" />
                </div>
              </div>
              <div className="font-bold text-2xl">
                <span className="text-white">Mining</span>
                <span className="text-green-500">Tech</span>
              </div>
            </Link>
          </div>

          {/* Search bar - desktop */}
          <div className="hidden md:flex flex-1 mx-6 relative">
            <Input
              type="text"
              placeholder="Поиск майнеров и комплектующих..."
              className="w-full rounded-full pl-4 pr-12 bg-gray-800 border-gray-700 text-white focus:border-purple-500"
            />
            <Button
              size="icon"
              variant="ghost"
              className="absolute right-0 top-0 h-full rounded-r-full bg-gray-700 hover:bg-gray-600"
            >
              <Search className="h-5 w-5 text-white" />
            </Button>
          </div>

          {/* Navigation and user actions */}
          <div className="flex items-center gap-2">
            <Link href="/mining-assistant">
              <Button variant="outline" className="hidden md:inline-flex border-purple-700 bg-gray-800 text-white hover:bg-gray-700">
                <MessageSquare className="mr-2 h-4 w-4" />
                Mining Assistant
              </Button>
            </Link>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="border-gray-700 bg-gray-800 text-white hover:bg-gray-700 hidden md:flex">
                  <span className="mr-2">Каталог</span>
                  <Settings className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-gray-800 text-white border-gray-700">
                <DropdownMenuItem className="hover:bg-gray-700">
                  <Link href="/asic-miners" className="flex w-full">ASIC майнеры</Link>
                </DropdownMenuItem>
                <DropdownMenuItem className="hover:bg-gray-700">
                  <Link href="/parts" className="flex w-full">Комплектующие</Link>
                </DropdownMenuItem>
                <DropdownMenuItem className="hover:bg-gray-700">
                  <Link href="/cooling" className="flex w-full">Системы охлаждения</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-gray-700" />
                <DropdownMenuItem className="hover:bg-gray-700">
                  <Link href="/services" className="flex w-full">Услуги и ремонт</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Link href="/cart">
              <Button variant="outline" size="icon" className="relative border-gray-700 bg-gray-800 text-white hover:bg-gray-700">
                <ShoppingCart className="h-5 w-5" />
                <span className="absolute -top-1 -right-1 bg-green-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  0
                </span>
              </Button>
            </Link>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon" className="border-gray-700 bg-gray-800 text-white hover:bg-gray-700">
                  <User className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-gray-800 text-white border-gray-700">
                <DropdownMenuLabel>Мой аккаунт</DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-gray-700" />
                <DropdownMenuItem className="hover:bg-gray-700">Мои заказы</DropdownMenuItem>
                <DropdownMenuItem className="hover:bg-gray-700">Избранное</DropdownMenuItem>
                <DropdownMenuItem className="hover:bg-gray-700">Профиль</DropdownMenuItem>
                <DropdownMenuSeparator className="bg-gray-700" />
                <DropdownMenuItem className="hover:bg-gray-700">Выйти</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button
              variant="outline"
              size="icon"
              className="md:hidden border-gray-700 bg-gray-800 text-white hover:bg-gray-700"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Mobile search bar */}
        <div className="mt-3 md:hidden relative">
          <Input
            type="text"
            placeholder="Поиск майнеров и комплектующих..."
            className="w-full rounded-full pl-4 pr-12 bg-gray-800 border-gray-700 text-white"
          />
          <Button
            size="icon"
            variant="ghost"
            className="absolute right-0 top-0 h-full rounded-r-full bg-gray-700 hover:bg-gray-600"
          >
            <Search className="h-5 w-5 text-white" />
          </Button>
        </div>
      </div>
    </header>
  );
}
