/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  distDir: 'out',
  images: {
    unoptimized: true, // Для статичного экспорта
    domains: [
      "source.unsplash.com",
      "images.unsplash.com",
      "ext.same-assets.com",
      "ugc.same-assets.com",
      "example.com", // Added domain for SVG support
    ],
    remotePatterns: [
      {
        protocol: "https",
        hostname: "**", // Updated pattern for all hostnames
      },
    ],
  },
  // Add this to ignore TypeScript errors in production build
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    // Warning: This allows production builds to successfully complete even if
    // your project has ESLint errors.
    ignoreDuringBuilds: true,
  },
};

if (process.env.NODE_ENV === 'development') {
  nextConfig.experimental = {
    ...nextConfig.experimental,
    esmExternals: 'loose',
  };
}

module.exports = nextConfig;
